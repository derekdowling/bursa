#
# Cookbook Name:: bursa-bitcoincore
# Recipe:: default
#
# Copyright (c) 2014 The Authors, All Rights Reserved.
#
apt_repository "bitcoin" do
   uri "http://ppa.launchpad.net/bitcoin/bitcoin/ubuntu "
   distribution node['lsb']['codename']
   components ["main"]
   keyserver "keyserver.ubuntu.com"
   key "8842CE5E"
end
